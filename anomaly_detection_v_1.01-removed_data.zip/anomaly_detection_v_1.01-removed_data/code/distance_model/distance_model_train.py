# -*- coding: utf-8 -*-
"""
Created on Wed Aug 11 14:20:19 2021

@author: Qiongge Li 

contact: qli78@jhmi.edu

"distance model" anomaly detection algorithm

"""
import os
import pandas as pd
import numpy as np
import tqdm
import gower
from sklearn.metrics import pairwise_distances, f1_score, average_precision_score, accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import MinMaxScaler
from plotting_helper import plot_stuff

plot_things = False

def detect(params):
    '''
    parameters:
                
        m  - number of sample in historical to average closest Rx over entered as % of historical db size
        n  - number of sample in historical database to average feature distance over entered as % of historical db %
        a  - rx threshold coefficient
        b  - feature threshold coefficeint
    '''
    ################## input parameters ##############
    
    rx_percent,f_percent,rx_tolerance,f_tolerance = params
    
    number_of_holdouts = 30

    ############## init ##############################
    
    flagged=[]
    warning=[]
    
    ########## load data ##########
    
    # base_path = r'C:\ENTER_YOUR_PATH_WHERE_YOU_PUT_ANOMALY_DETECTION_FOLDER_HERE'
    # for example: 
    base_path = r'C:\Users\qli78\OneDrive - Johns Hopkins\My_residency\Research\PeerReview\anomaly_detection_v_1.01'
    
    techn = 'sbrt' #USER'S INPUT
    
    # train_or_test = 'train' #USER'S INPUT
    train_or_test = 'test' #USER'S INPUT
    
    historical_data_path = os.path.join(base_path, 'data\\train\historical\\' + techn + '\\')
    
    df_normal = pd.read_excel(historical_data_path + techn+'_historical.xlsx') 
    df_normal.reset_index(drop=True, inplace=True)
    
    anomaly_data_path = os.path.join(base_path,'data\\'+train_or_test+'\\anomalies\\' + techn + '\\')
    
    #anom_type = 'feature_anomalies'
    #anom_type = 'switching_anomalies'
    #anom_type = 'train_anomalies' 
    
    anom_type = 'test_anomalies'
    
    df_anom=pd.read_excel(anomaly_data_path + techn+'_'+anom_type+'.xlsx') 
    df_anom.reset_index(drop=True, inplace=True)
    
    ############ transformations #######################
    
    size_db = len(df_normal.index) - number_of_holdouts
    
    m = int(rx_percent*size_db)
    n = int(f_percent*size_db)
    
    # change icdo code to type string
    df_normal['icdo_code'] = df_normal['icdo_code'].astype(str)
    # change icdo code to type string
    df_anom['icdo_code'] = df_anom['icdo_code'].astype(str)
    
    if True: 
        df_normal= df_normal.sample(frac = 1)#shuffle
        
        if train_or_test == 'test':
            number_of_holdouts = 0
            n_path = os.path.join(base_path,'data\\'+train_or_test+'\historical\\' + techn + '\\')
            df_holdout_not_anomaly = pd.read_excel(n_path + techn+'_test_normal.xlsx') 
        else:    
            df_holdout_not_anomaly = df_normal.iloc[:number_of_holdouts].copy()
        df_holdout_not_anomaly['ground_truth'] = 0
        df_historical=df_normal.iloc[number_of_holdouts:]
        
        df_anom['ground_truth'] = 1
        # append 
        df_out=df_anom.append(df_holdout_not_anomaly,sort=False)
        df_out.reset_index(drop=True, inplace=True)
        df_out['prediction'] = np.nan
        df_out['type'] = np.nan
        df_out['R'] = np.nan
        df_out['t_rx'] = np.nan
        df_out['F'] = np.nan
        df_out['t_f'] = np.nan
        df_out['count_same'] = np.nan
    
        ############### compute historical Rx and feature distance ###############################
        
        historical_Rx_unscaled=df_historical[['Fractions','Dose_Tx']]
        rxscaler = MinMaxScaler()
        rxscaler.fit(historical_Rx_unscaled)
        historical_Rx_scaled = rxscaler.transform(historical_Rx_unscaled)
        historical_Rx_dist=pairwise_distances(historical_Rx_scaled, metric='euclidean')
        
        # calculate the mean of the distance matrix
        historical_Rx_dist_mean = historical_Rx_dist.mean()
        historical_Rx_dist_min = historical_Rx_dist.min()
        historical_Rx_dist_max = historical_Rx_dist.max()
        
        historical_features=df_historical[['Modality_numerical', 'Tx_Intent', 'diag_code','Age_Tx','icdo_code']]
         
        historical_feature_dist = gower.gower_matrix(historical_features)
        
        historical_feature_dist_min=historical_feature_dist.min()
        historical_feature_dist_max=historical_feature_dist.max()
        historical_feature_dist_mean=historical_feature_dist.mean()
        
        df_test=df_anom.append(df_holdout_not_anomaly,sort=False)
        df_test.reset_index(drop=True, inplace=True)
        
        ##### optional plotting ##########
        if plot_things is True:
            plot_stuff(historical_Rx_dist,historical_feature_dist)
        
        for i in tqdm.tqdm(list(df_test.index)):
        
            df_test_patient=df_test.loc[[i]]
               
            ######################## process new patient ################################
            
            #  process features for test patient
            test_patient_features=df_test_patient[['Modality_numerical', 'Tx_Intent', 'diag_code','Age_Tx','icdo_code']]
    
            # Rx for test patient
            test_patient_Rx_unscaled=df_test_patient[['Fractions','Dose_Tx']]
            #Rx_scaled=preprocessing.scale(Rx)
        
            test_patient_Rx_scaled = rxscaler.transform(test_patient_Rx_unscaled)
            test_patient_Rx_dist=pairwise_distances(test_patient_Rx_scaled,historical_Rx_scaled, metric='euclidean')
            
            count_same=sum(test_patient_Rx_dist[0,:]==0)
            mins_m=np.sort(test_patient_Rx_dist[0,:])[:m]
            R = mins_m.mean()
            df_out.loc[i,'R'] = R
            df_out.loc[i,'count_same'] = count_same
            
            tR = rx_tolerance*historical_Rx_dist_mean
            df_out.loc[i,'t_rx'] = tR
            
            if R > tR:
                # print("flagged Rx")
                flagged.append("3")
                df_out.loc[i,'prediction'] = 1
                df_out.loc[i,'type'] = 3
            else:
 
                test_patient_feature_dist=gower.gower_matrix(data_x=historical_features,data_y=test_patient_features)
                
                sort_this_out = None
                sort_this_out = pd.DataFrame()
                srt_Rx_dists = np.sort(test_patient_Rx_dist)
                sort_this_out['srt_Rx_dists'] = np.ravel(srt_Rx_dists)
                sort_this_out['inds'] =  np.argsort(test_patient_Rx_dist[0,:])
                sort_this_out['feature_dists'] = test_patient_feature_dist[np.argsort(test_patient_Rx_dist[0,:])]
                sort_this_out = sort_this_out.sort_values(by=['srt_Rx_dists','feature_dists'])
                
                new_feature_dist_filtered = sort_this_out['feature_dists']
                
                if len(np.argwhere(test_patient_Rx_dist[0,:]==0))<n:
                    warning.append('for patient '+str(i)+' only '+str(len(np.argwhere(test_patient_Rx_dist[0,:]==0)))+' patients with same Rx but n = '+str(n))
                
                F = np.round(new_feature_dist_filtered[:n].mean(),3)
    
                df_out.loc[i,'F'] = F
                
                tF = f_tolerance*historical_feature_dist_mean
                df_out.loc[i,'t_f'] = tF
                
                if F > tF:
                    # print("Flagged for large feature distance even though we have seen this Rx before, feature distance is very large to previous patients with same Rx")
                    flagged.append("2")
                    df_out.loc[i,'prediction'] = 1
                    df_out.loc[i,'type'] = 2
                else:
                    # print(" no flag for patient")
                    flagged.append("0")
                    df_out.loc[i,'prediction'] = 0
        
        #%% evaluate the model
        y_true=df_out['ground_truth']
        y_pred=df_out['prediction']
        
        f1sc = f1_score(y_true, y_pred)
        #prec = average_precision_score(y_true, y_pred)
        #acc = accuracy_score(y_true, y_pred, normalize=True)
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    
    return -1*f1sc
    
    

