# -*- coding: utf-8 -*-
"""
Created on Sun Aug 22 15:39:45 2021

Below are the parameters given in the paper.

In order to replicate those results, we can run the distance model 50 times
and average the result to check. 

To perform the tests, uncomment the parameter and case that you want to check

@author: Qiongge Li 

contact: qli78@jhmi.edu
"""

import numpy as np
from distance_model_train import detect


####### SBRT  ##################
# Rx switch 
# params = [0.014,0.047,1.631,1.838]   #PASS

#feature - switch
# params =  [0.029,0.017,0.307,0.584]  # FAIL got .87

#combined in-sample
#params = [ 0.075,0.01,1.926,0.465]  # PASS

# out-sample
params = [.075,.01,1.93,.465]  # PASS
# outsample parameters are the same as combined in-sample

############# IMRT ###########
#Rx switch 
#params = [0.014,0.025,0.265,0.979]  # PASS but increase sd to 0.05 .03

#feature switch
#params =   [0.038,0.023,0.286, 0.802] # PASS a little bigger sd

#combined in-sample
# params = [.014,.025,1.4,.805]  # PASS but got .85 instead .86 .03

# outsample parameters are the same as combined in-sample

########  3d ###########################

#Rx switch
#params = [0.018,0.012,0.449,1.632]   #PASS

# feature switch
#params =  [0.019, 0.021,0.056, 0.797]   # PASS (forgot to update detect in first trials)

#combined in-sample
# params = [.037,.01,.01,.707]   # give a PASS but it is 0.83  sd .03

# outsample parameters are the same as combined in-sample

l=[]

for i in range(5): #for shuffle run; 1 is default
    l.append(detect(params))
print(' ')
print(' ')
print('The mean f1 score is: ')
print(np.mean(l))
print(' ')
print('The stdv is: ')
print(np.std(l))