# -*- coding: utf-8 -*-
"""
Created on Thu Aug  5 18:41:12 2021
@author: Qiongge Li 

contact: qli78@jhmi.edu
"""


# define a search space
import hyperopt
from hyperopt import hp
import numpy as np
# from anomaly_detect_check_and_fix_v1 import detect
from distance_model_train import detect 


space = [hp.loguniform('r', np.log(.01), np.log(.1)),
hp.loguniform('f', np.log(.01), np.log(0.1)),
hp.loguniform('a', np.log(.01), np.log(2.0)),
hp.loguniform('b', np.log(.01), np.log(2.0))] # USER'S INPUT, OPTIONAL


# minimize the objective over the space
from hyperopt import fmin, tpe
best = fmin(detect, space, algo=tpe.suggest, max_evals=100) # USER'S INPUT, OPTIONAL

print(best)
# -> {'a': 1, 'c2': 0.01420615366247227}
print(hyperopt.space_eval(space, best))

