# -*- coding: utf-8 -*-
"""
Created on Wed Aug 11 14:34:11 2021

@author: Qiongge Li 

contact: qli78@jhmi.edu
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy
#import numpy as np
import seaborn as sns;

def plot_stuff(historical_Rx_dist,historical_feature_dist):
    
    output_path = r'C:\Users\maxya\Dropbox\mqshare2\mq_share\Rx_prediction\Rx_prediction\Output\thoracic\\'
    
    ax = sns.heatmap(historical_Rx_dist);
    plt.savefig(output_path + 'Figures/heatmap_r.jpg');
    
    plt.clf();
    ax = sns.heatmap(historical_feature_dist);
    plt.savefig(output_path + 'Figures/heatmap_f.jpg');
    
    plt.clf();
    
    plt.figure();
    # make histgram of feature distance
    cc=scipy.spatial.distance.squareform(historical_feature_dist,checks=False);
    cd=pd.Series(cc);
    cd.hist(density=True);
    
    plt.savefig(output_path + 'Figures/histogram_f.jpg');
    
    plt.clf();
    
    plt.figure();
    
    cc=scipy.spatial.distance.squareform(historical_Rx_dist,checks=False);
    cd=pd.Series(cc);
    cd.hist(density=True);

    plt.savefig(output_path + 'Figures/histogram_r.jpg');
    plt.clf();
    plt.figure();