# -*- coding: utf-8 -*-
"""
Created on Wed Aug 18 10:32:45 2021

@author: Qiongge Li 

contact: qli78@jhmi.edu


1. uses random minority oversampling to balance class from imblearn module
2. then uses random forest to predict on the MOC test set
3. you cannot use cross-validation to the repeated samples, but we can loop to find
   the best random forest hyperparameters usually you want max_depth to be around 3 or 4 
   but you need to test it. You can also change the number of trees in the forest
   by changing the n_estimators

"""

import os
import numpy as np
import pandas as pd

import matplotlib.pyplot as plt

from imblearn.over_sampling import RandomOverSampler
from sklearn.ensemble import  RandomForestClassifier
from sklearn.model_selection import GridSearchCV, cross_val_score, cross_val_predict
import utilities
from sklearn.metrics import f1_score


base_path = r'C:\ENTER_YOUR_PATH_WHERE_YOU_PUT_ANOMALY_DETECTION_FOLDER_HERE'
# for example:
# base_path = r'C:\Users\qli78\OneDrive - Johns Hopkins\My_residency\Research\PeerReview\anomaly_detection_v_1.01'
#load data
techn = '3d' 

historical_data_path = os.path.join(base_path, 'data\\train\historical\\' + techn + '\\')

df_normal = pd.read_excel(historical_data_path + techn+'_historical.xlsx') 
    
train_anomaly_data_path = os.path.join(base_path,'data\\train\\anomalies\\' + techn + '\\')

df_anom=pd.read_excel(train_anomaly_data_path + techn+'_train_anomalies.xlsx') 

# pre-processing
df_normal['icdo_code'] = df_normal['icdo_code'].astype(str)
# change icdo code to type string
df_anom['icdo_code'] = df_anom['icdo_code'].astype(str)

df_normal['ground_truth'] = 0
df_anom['ground_truth'] = 1

df=df_anom.append(df_normal)
df.reset_index(drop=True, inplace=True)

df= df.sample(frac = 1)#shuffle

test_anomaly_data_path = os.path.join(base_path,'data\\test\\anomalies\\' + techn + '\\')
test_normal_data_path = os.path.join(base_path,'data\\test\\historical\\' + techn + '\\')

df_test_A = pd.read_excel(test_anomaly_data_path + techn+'_test_anomalies.xlsx') 
df_test_N =  pd.read_excel(test_normal_data_path + techn+'_test_normal.xlsx') 

df_test_N['ground_truth'] = 0
df_test_A['ground_truth'] = 1

df_test = df_test_N.append(df_test_A)

df_f = df.append(df_test)
df_f.reset_index(drop=True, inplace=True)

ResponseName = 'ground_truth'
RelevantFeatureNames = ['Fractions','Dose_Tx','Modality_numerical', 'Tx_Intent', 'diag_code','Age_Tx','icdo_code']


X = df_f.loc[:,RelevantFeatureNames]
X = pd.get_dummies(X)

y = df_f.loc[:,ResponseName]

if techn == 'imrt':
    num=1202
elif techn == 'sbrt':
    num=751
elif techn == '3d':
    num=559
    
X_train = X[:num]
y_train = y[:num]

X_test = X[num:]
y_test = y[num:]

ros = RandomOverSampler(random_state=0)

accs_os = []
recalls_os = []
prec_os = []
specs_os = []
f1s_os = []

accs_is = []
recalls_is = []
prec_is = []
specs_is = []
f1s_is = []

ll=0
#===================================CHANGE HYPERPARAMETERS =====================
for n_estimators in range(8,10): # USER'S INPUT, OPTIONAL: search space for n_estimators
    for depth in range(1,5): # USER'S INPUT, OPTIONAL: search space for depth
    
        for i in range(10):
        
            X_train_resampled, y_train_resampled = ros.fit_resample(X_train.values,y_train.values)
            
            ##########################################################################
            
            clf = RandomForestClassifier(max_depth=depth,n_estimators=n_estimators)
            
            clf.fit(X_train_resampled, y_train_resampled)
            
            y_pred_train = clf.predict(X_train_resampled)
            y_pred_test = clf.predict(X_test)
            
            in_sample = utilities.get_metrics(y_train_resampled, y_pred_train)
            
            accs_is.append(in_sample['accuracy'])
            recalls_is.append(in_sample['recall'])
            prec_is.append(in_sample['precision'])
            specs_is.append(in_sample['specificity'])
            
            out_sample = utilities.get_metrics(y_test,y_pred_test)
            
            accs_os.append(out_sample['accuracy'])
            recalls_os.append(out_sample['recall'])
            prec_os.append(out_sample['precision'])
            specs_os.append(out_sample['specificity'])
            
        
            f1s_is.append(f1_score(y_train_resampled,y_pred_train))
            f1s_os.append(f1_score(y_test,y_pred_test))
        
        if ll== 0:
            #print(' ')
            #print('n_estimators ', n_estimators)
            #print('max_depth ',depth)
            #print(' ')
            d_is = {'f1':[np.mean(f1s_is)],'accuracy':[np.mean(accs_is)],'recall':[np.mean(recalls_is)],'precision':[np.mean(prec_is )],'specificity':[np.mean(specs_is)],'n_trees':[n_estimators],'depth':[depth]}
            #print('\n in_sample')
            iss = pd.DataFrame(d_is)
            
            
            d_os = {'f1':[np.mean(f1s_os)],'accuracy':[np.mean(accs_os)],'recall':[np.mean(recalls_os)],'precision':[np.mean(prec_os )],'specificity':[np.mean(specs_os)],'n_trees':[n_estimators],'depth':[depth]}
            #print('\n out_sample')
            oss = pd.DataFrame(d_os)
        else:
            iss.loc[ll] = [np.mean(f1s_is),np.mean(accs_is),np.mean(recalls_is),np.mean(prec_is ),np.mean(specs_is),n_estimators,depth]
            oss.loc[ll] = [np.mean(f1s_os),np.mean(accs_os),np.mean(recalls_os),np.mean(prec_os ),np.mean(specs_os),n_estimators,depth]

print('')
print('in sample')
print(iss)

print('')
print('out of sample')
print(oss)
#oss.to_excel(techn+'_supervised_learning_RF_out_sample.xlsx')
#iss.to_excel(techn+'_supervised_learning_RF_in_sample.xlsx')
