
import os
import sys
import itertools

import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

import seaborn as sns

from sklearn.metrics import confusion_matrix, accuracy_score, recall_score, precision_score

# Check if graphviz is installed, if not, set flag to False
has_graphviz = True
try:
    import graphviz
except ImportError:
    has_graphviz = False

def get_metrics(y_test, y_pred):
    '''
    Return a DataFrame containing accuracy, recall, precision, specificity
    '''

    dict_metrics = dict()
    cnf = confusion_matrix(y_test, y_pred)

    # Split the confusion matrix into components.
    tn, fp, fn, tp = cnf.ravel()

    accuracy  = accuracy_score(y_test, y_pred)
    recall    = recall_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    specificity = tn / (fp + tn)

    dict_metrics['accuracy']    = accuracy
    dict_metrics['recall']      = recall
    dict_metrics['precision']   = precision
    dict_metrics['specificity'] = specificity

    df = pd.DataFrame.from_dict(dict_metrics, orient='index').T

    return df
    
def check_confusion_matrix(y_test, y_pred):
    '''
    Check that we are getting the elements of the confusion matrix correctly
    and that manual calculation of accuracy, recall, precision match that of sklearn.
    '''

    cnf = confusion_matrix(y_test, y_pred)

    # Split the confusion matrix into components.
    # See http://scikit-learn.org/stable/modules/model_evaluation.html
    # for order of elements in confusion_matrix
    tn, fp, fn, tp = cnf.ravel()

    accuracy  = accuracy_score(y_test, y_pred)
    recall    = recall_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    print('accuracy  = ' + str(accuracy))
    print('recall    = ' + str(recall))
    print('precision = ' + str(precision))
    
    # Compare manually
    _accuracy  = (tp + tn) / + (tp + fp + fn + tn)
    _recall    = tp / (tp + fn)
    _precision = tp / (tp + fp)
    if _accuracy != accuracy:
        print('accuracy is wrong')
        sys.exit(-1)
    if _recall != recall:
        print('recall is wrong')
        sys.exit(-1)
    if _precision != precision:
        print('precision is wrong')
        sys.exit(-1)

def create_confusion_matrix_plot(y_test, y_pred, class_names, title=''):
    '''
    Create plot of confusion matrix customized to show same result as from Matlab.
    '''
    # Create confusion matrix
    cnf = confusion_matrix(y_test, y_pred)
    # Split the confusion matrix into components.
    tn, fp, fn, tp = cnf.ravel()
    total = tn + fp + fn + tp
    
    # check_confusion_matrix(y_test, y_pred)
    
    # Create 3x3 array for colors
    green = -1
    orange = 1
    colorboxes = np.array(((green, orange, 0), (orange, green, 0), (0, 0, 0)))
    
    fig, ax = plt.subplots(1, 1)

    # Set title from input
    if title not in ['', None]:
        fig.suptitle(title, fontweight='bold', fontsize=12, color='k')
    
    fig.subplots_adjust(left=0.10, bottom=0.25)
    ax.imshow(colorboxes, origin='upper', interpolation='nearest', cmap='coolwarm', alpha=0.3) # , extent=(0, 3, 0, 3)
    ax.grid(False)
    ax.set_xticks([0, 1, 2])
    ax.set_yticks([0, 1, 2])
    # ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    # ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    
    ax.set_xticklabels(class_names) # , ha='center')
    ax.set_yticklabels(['Predicted\n' + c if c!= '' else '' for c in class_names]) # , ha='center')
    
    ax.set_xlabel('Target Class', labelpad=30, fontsize=12, fontweight='bold')
    ax.set_ylabel('Output Class', labelpad=30, fontsize=12, fontweight='bold')
    
    # Fill text for each cell
    col = 0
    row = 0
    ax.text(col, row - 0.2, str(tp), ha='center', va='center', color='k', fontweight='bold')
    ax.text(col, row     , "{:.1f}".format(100 * tp / total) + '%', ha='center', va='center', color='k', fontsize=9)
    ax.text(col, row + 0.2, 'True Positives', ha='center', va='center', color='k', fontsize=9)
    
    col = 1
    row = 0
    ax.text(col, row - 0.2, str(fp), ha='center', va='center', color='k', fontweight='bold')
    ax.text(col, row     , "{:.1f}".format(100 * fp / total) + '%', ha='center', va='center', color='k', fontsize=9)
    ax.text(col, row + 0.2, 'False Positives', ha='center', va='center', color='k', fontsize=9)
    ax.text(col, row + 0.4, 'Type I error', ha='center', va='center', color='k', fontsize=9)
    
    col = 2
    row = 0
    precision = 100 * precision_score(y_test, y_pred)
    ax.text(col, row - 0.2, "{:.1f}".format(precision) + '%', ha='center', va='center', color='g', fontsize=9)
    ax.text(col, row     , "{:.1f}".format(100 - precision) + '%', ha='center', va='center', color='r', fontsize=9)
    ax.text(col, row + 0.2, 'Precision', ha='center', va='center', color='g', fontsize=9)
    
    col = 0
    row = 1
    ax.text(col, row - 0.2, str(fn), ha='center', va='center', color='k', fontweight='bold')
    ax.text(col, row     , "{:.1f}".format(100 * fn / total) + '%', ha='center', va='center', color='k', fontsize=9)
    ax.text(col, row + 0.2, 'False Negatives', ha='center', va='center', color='k', fontsize=9)
    ax.text(col, row + 0.4, 'Type II error', ha='center', va='center', color='k', fontsize=9)
    
    col = 1
    row = 1
    ax.text(col, row - 0.2, str(tn), ha='center', va='center', color='k', fontweight='bold')
    ax.text(col, row     , "{:.1f}".format(100 * tn / total) + '%', ha='center', va='center', color='k', fontsize=9)
    ax.text(col, row + 0.2, 'True Negatives', ha='center', va='center', color='k', fontsize=9)
    
    col = 2
    row = 1
    npv = 100 * tn / (tn + fn)
    ax.text(col, row - 0.2, "{:.1f}".format(npv) + '%', ha='center', va='center', color='g', fontsize=9)
    ax.text(col, row     , "{:.1f}".format(100 - npv) + '%', ha='center', va='center', color='r', fontsize=9)
    ax.text(col, row + 0.2, 'Negative Predictive\nValue', ha='center', va='center', color='g', fontsize=9)
    
    col = 0
    row = 2
    recall = 100 * recall_score(y_test, y_pred)
    ax.text(col, row - 0.2, "{:.1f}".format(recall) + '%', ha='center', va='center', color='g', fontsize=9)
    ax.text(col, row     , "{:.1f}".format(100 - recall) + '%', ha='center', va='center', color='r', fontsize=9)
    ax.text(col, row + 0.2, 'Sensitivity (Recall)', ha='center', va='center', color='g', fontsize=9)
    
    col = 1
    row = 2
    specificity = 100 * tn / (fp + tn)
    ax.text(col, row - 0.2, "{:.1f}".format(specificity) + '%', ha='center', va='center', color='g', fontsize=9)
    ax.text(col, row     , "{:.1f}".format(100 - specificity) + '%', ha='center', va='center', color='r', fontsize=9)
    ax.text(col, row + 0.2, 'Specificity', ha='center', va='center', color='g', fontsize=9)
    
    col = 2
    row = 2
    accuracy = 100 * accuracy_score(y_test, y_pred)
    ax.text(col, row - 0.2, "{:.1f}".format(accuracy) + '%', ha='center', va='center', color='g', fontsize=9)
    ax.text(col, row     , "{:.1f}".format(100 - accuracy) + '%', ha='center', va='center', color='r', fontsize=9)
    ax.text(col, row + 0.2, 'Accuracy', ha='center', va='center', color='g', fontsize=9)

    # Return the created fig and ax
    return fig, ax

def plot1CVscore(results,pram):
    ''' 
    plot crossvalidation scores
    '''
    
    plt.title("GridSearchCV evaluating score vs hyperparameter",
          fontsize=16)

    plt.xlabel(pram)
    plt.ylabel("Score")
    
    ax = plt.gca()
    #fig, ax = plt.subplots(1,1)
    #ax.set_xlim(0, 20)
    #ax.set_ylim(0.73, 1)
    
    # Get the regular numpy array from the MaskedArray
    X_axis = np.array(results['param_' + pram].data, dtype=float)
    

    for sample, style in (('train', '--'), ('test', '-')):
        sample_score_mean = results['mean_%s_score' % sample]
        sample_score_std = results['std_%s_score' % sample]
        ax.fill_between(X_axis, sample_score_mean - sample_score_std,
                        sample_score_mean + sample_score_std,
                        alpha=0.1 if sample == 'test' else 0)
        ax.plot(X_axis, sample_score_mean, style,
                alpha=1 if sample == 'test' else 0.7,
                label= sample)
    
        #best_index = np.nonzero(results['rank_test_%s' % scorer] == 1)[0][0]
        #best_score = results['mean_test_%s' % scorer][best_index]
    
        # Plot a dotted vertical line at the best score for that scorer marked by x
        #ax.plot([X_axis[best_index], ] * 2, [0, best_score],
               #linestyle='-.', color=color, marker='x', markeredgewidth=3, ms=8)
    
        # Annotate the best score for that scorer
        #ax.annotate("%0.2f" % best_score,
                    #(X_axis[best_index], best_score + 0.005))
    
    plt.legend(loc="best")
    plt.grid(False)
    plt.show()
    #return fig, ax

def plot2CVscores(results,scoring):
    ''' 
    plot crossvalidation scores
    '''
    
    plt.title("GridSearchCV evaluating using multiple scorers simultaneously",
          fontsize=16)

    plt.xlabel("max_depth")
    plt.ylabel("Score")
    
    ax = plt.gca()
    #fig, ax = plt.subplots(1,1)
    #ax.set_xlim(0, 20)
    #ax.set_ylim(0.73, 1)
    
    # Get the regular numpy array from the MaskedArray
    X_axis = np.array(results['param_max_depth'].data, dtype=float)
    
    for scorer, color in zip(sorted(scoring), ['g', 'k']):
        for sample, style in (('train', '--'), ('test', '-')):
            sample_score_mean = results['mean_%s_%s' % (sample, scorer)]
            sample_score_std = results['std_%s_%s' % (sample, scorer)]
            ax.fill_between(X_axis, sample_score_mean - sample_score_std,
                            sample_score_mean + sample_score_std,
                            alpha=0.1 if sample == 'test' else 0, color=color)
            ax.plot(X_axis, sample_score_mean, style, color=color,
                    alpha=1 if sample == 'test' else 0.7,
                    label="%s (%s)" % (scorer, sample))
    
        #best_index = np.nonzero(results['rank_test_%s' % scorer] == 1)[0][0]
        #best_score = results['mean_test_%s' % scorer][best_index]
    
        # Plot a dotted vertical line at the best score for that scorer marked by x
        #ax.plot([X_axis[best_index], ] * 2, [0, best_score],
               #linestyle='-.', color=color, marker='x', markeredgewidth=3, ms=8)
    
        # Annotate the best score for that scorer
        #ax.annotate("%0.2f" % best_score,
                    #(X_axis[best_index], best_score + 0.005))
    
    plt.legend(loc="best")
    plt.grid(False)
    plt.show()
    #return fig, ax

def create_tree_graph(tree):
    '''
    Take in a fitted decision tree and create a graphical representation.
    '''

    # If graphviz is not installed, nothing to do
    if has_graphviz == False:
        print('Library graphviz is not installed')
        print('Please use an environment where it is installed')
        return

    # Export the graph data into a stream
    dot_data = io.StringIO()
    export_graphviz(dtree, out_file=dot_data,  
                filled=True, rounded=True,
                special_characters=True)

    # Create a graph object from the stream containing the graph
    graph =Source(dot_data.getvalue())
    graph.format = 'png'
    graph.render('dtree_render',view=True)



def main(agv):
    # Data and labels
    y_test = [0] * (6662 + 315) + [1] * (684 + 1339)
    y_pred = [0] * 6662 + [1] * 315 + [0] * 1339 + [1] * 684
    class_names = ['Defaults', 'No Defaults', '']
    
    fig, ax = create_confusion_matrix_plot(y_test, y_pred, class_names)

    df_metrics = get_metrics(y_test, y_pred)
    print(df_metrics)

if __name__ == '__main__':
    main(sys.argv[1:])
    
