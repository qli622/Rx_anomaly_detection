
	Anomaly detection tool to assist RT clinical chart rounds
	
	created by Qiongge Li 

	contact: qli78@jhmi.edu 
	
	
 

	=========== CODE INSTRUCTIONS =====================
	
	There are four python scripting files
	
	1. distance_model_train.py
	
		a. The main code that runs the distance model
		b. You will need to modify the base_path to wherever you placed the anomaly detection folder
		i.e. base_path = r'C:\Users\qli78\anomaly_detection_v_1.01'
		c. You will need to switch "train" to "test" for "training" or "testing", respectively
		d. You will need to select the techn to be either '3d', or 'imrt' or 'sbrt'
		
	2. optimizer_hyperopt.py
	
		a. This code is for hyper parameter optimization
		b. You can modify number of evals or search space to improve the optimization: 
		c. You will need to make sure to reload the distance_model_train.py, prior to running this code,
		if you make any changes to the techn or the train/test
	   
	3. test_script.py
	
		a. Use this script to replicate results published in the paper
		b. The last sentence before print will allow you to run more than once by changing the num inside of range()
		and allow you to obtain the stdv
		c. Uncomment params line each at a time
		d. You will need to go back to distance_model_train.py to change train_or_test 
		or techn accordingly		
		
	4. random_forest_ROS.py
	
		Random minority oversampling Random Forest. 
		You can modify the loops over hyperparameters to perform larger searches
		Uncomment the last two lines to write out the results of hyperparameter optimization


	============= DEPENDENCIES ===================
	
	1. Python 2.7 or 3.X
	
	2. sklearn, imblearn, gower, pandas (+ other standard libraries)
	
	   to install imblearn or gower, use anaconda prompt:
	   
	   >> pip install gower
	   
	   >> pip install imblearn
	   


